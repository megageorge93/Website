from django.contrib import admin
#from personal.models import Question
# Register your models here.

#admin.site.register(Question)

