#!d:\progra~2\website\newbie~1\newsite\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
